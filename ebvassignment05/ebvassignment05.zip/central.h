#ifndef CENTRAL_H_INCLUDED
#define CENTRAL_H_INCLUDED

#ifdef _WIN32
#define WIN32
#endif

#ifdef WIN32
#define _USE_MATH_DEFINES
#endif
#include <math.h>
#include <stdio.h>
#include <string>
#include <assert.h>
#include <algorithm>
using namespace std;

#endif